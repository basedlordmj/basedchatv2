# basedchat backend

Node.js + Express + PostgreSQL backend for the basedchat frontend: accounts, video feed,
likes/comments/reposts with XP & levels, a leaderboard, and DMs/groupchats over WebSockets.

## Stack
- **Express** — REST API
- **PostgreSQL** (`pg`) — database
- **Socket.io** — real-time messaging
- **Multer** — video/image uploads to local disk (`/uploads`, served statically). Swap for
  S3 later by changing `src/middleware/upload.js`'s storage engine — nothing else needs to change.
- **JWT** (`jsonwebtoken`) + **bcryptjs** — auth

## Setup

```bash
cd basedchat-backend
npm install
cp .env.example .env        # then edit JWT_SECRET and DATABASE_URL
```

Create the database (adjust to your local Postgres setup):

```bash
createdb basedchat
```

Run migrations:

```bash
npm run migrate
```

Start the server:

```bash
npm run dev      # auto-restarts on file changes
# or
npm start
```

**Now just open `http://localhost:4000` in your browser.** The backend serves the wired
`basedchat.html` frontend itself (from `public/`), already pointed at this exact server —
no separate frontend server, no CORS config, no editing URLs. Every time you restart the
backend and reload that page, you're testing against your local database.

The API is at `http://localhost:4000/api`, and uploaded files are served at
`http://localhost:4000/uploads/...`.

If you'd rather host the frontend somewhere else (a separate static server, a different
port, etc.), that still works — copy `public/basedchat.html` anywhere, and either set
`CLIENT_ORIGIN` in `.env` to that origin, or override the API target on the page with
`<script>window.BASEDCHAT_API_BASE = 'http://localhost:4000'</script>` before the app's
own script tag.

## Database schema

See `migrations/001_init.sql`. Tables: `users`, `videos`, `likes`, `comments`, `reposts`,
`xp_events` (audit log of every XP award), `conversations`, `conversation_participants`,
`messages`. User-facing IDs (`#10001` style) come from a sequence starting at 10001, separate
from the internal primary key.

## XP & levels

Defined in `src/utils/xp.js`, matching the frontend's level card:

| Level | Label | XP |
|---|---|---|
| 1 | rook | 0 |
| 2 | uploader | 250 |
| 3 | regular | 500 |
| 4 | cool mf | 1000 |
| 5 | rising star | 2000 |
| 6 | verified | 4000 |
| 7 | swag | 8000 |
| 8 | elite | 16000 |
| 9 | based | 32000 |
| 10 | based god | 64000 |

XP is awarded to a **video's author** (not the person taking the action) when someone likes
(+50), comments (+150), or reposts (+450) their video. Every award is logged in `xp_events`.
Un-liking/un-reposting does not claw back XP already earned — adjust `toggleLike`/`toggleRepost`
in `videosController.js` if you want different behavior.

## REST API

All authenticated routes expect `Authorization: Bearer <token>`.

**Auth**
- `POST /api/auth/register` `{ handle, email, password }` → `{ token, user }`
- `POST /api/auth/login` `{ email, password }` → `{ token, user }`
- `GET /api/auth/me` (auth) → `{ user }`

**Users**
- `GET /api/users?q=term` → search by handle or public ID
- `GET /api/users/:handleOrId` → profile (accepts `@handle` value without the `@`, or the numeric ID)
- `GET /api/users/leaderboard?sort=xp|posts` → top 50

**Videos**
- `GET /api/videos?cursor=&limit=` → paginated feed, newest first
- `GET /api/videos/:id` → single video
- `POST /api/videos` (auth, multipart: `video` file + `caption`, `trackLabel`, `durationSeconds`)
- `POST /api/videos/:id/like` (auth) → toggles, awards XP to author on like
- `POST /api/videos/:id/repost` (auth) → toggles, awards XP to author on repost
- `GET /api/videos/:id/comments`
- `POST /api/videos/:id/comments` (auth) `{ body }` → awards XP to author

**Conversations (DMs & groupchats)**
- `GET /api/conversations` (auth) → mine, most recent first
- `POST /api/conversations` (auth) `{ handles: ["alice"], isGroup?, name? }` → creates or reuses a DM
- `GET /api/conversations/:id/messages?before=&limit=` (auth)
- `POST /api/conversations/:id/messages` (auth) `{ body }` → also broadcasts over the socket
- `POST /api/conversations/:id/background` (auth, multipart `image`) → groupchat wallpaper

## WebSocket (Socket.io)

Connect with the JWT from login/register:

```js
import { io } from 'socket.io-client';
const socket = io('http://localhost:4000', { auth: { token: jwtToken } });

socket.on('message:new', (msg) => { /* append to thread */ });
socket.on('typing', ({ conversationId, user }) => { /* show typing indicator */ });

socket.emit('typing', { conversationId });
socket.emit('message:send', { conversationId, body: 'yo' }, (ack) => {
  if (!ack.ok) console.error(ack.error);
});
```

On connect, a socket auto-joins the rooms for every conversation the user is already in.
After creating a brand-new conversation via REST, join it live with:
`socket.emit('conversation:join', { conversationId })`.

## Frontend

`public/basedchat.html` is already fully wired to this API — auth, feed, likes/comments/
reposts, leaderboard, profile lookup, DMs/groupchats, and file uploads all call the
endpoints above. It stores its JWT in `localStorage` and opens a Socket.io connection
after login. There's nothing left to connect; just run the server and open it.

## Production notes
- Set a strong random `JWT_SECRET`.
- Put this behind HTTPS; set `CLIENT_ORIGIN` to your real frontend origin (no `*` in prod).
- Local disk storage doesn't scale across multiple server instances — move to S3/R2 when you
  need horizontal scaling (only `src/middleware/upload.js` needs to change).
- Add rate limiting on `/api/auth/*` and the comment/message endpoints before going public.
