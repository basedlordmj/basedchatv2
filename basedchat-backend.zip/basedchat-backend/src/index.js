require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth.routes');
const usersRoutes = require('./routes/users.routes');
const videosRoutes = require('./routes/videos.routes');
const conversationsRoutes = require('./routes/conversations.routes');
const { initSockets } = require('./sockets');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.CLIENT_ORIGIN || '*' },
});

app.set('io', io);

app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*' }));
app.use(express.json());
app.use('/uploads', express.static(path.join(process.cwd(), process.env.UPLOAD_DIR || 'uploads')));

// Serves the wired basedchat.html frontend directly from this backend, so
// visiting http://localhost:PORT always opens a working copy pointed at
// this exact server — no separate frontend server or CORS setup needed.
app.use(express.static(path.join(process.cwd(), 'public')));
app.get('/', (req, res) => res.sendFile(path.join(process.cwd(), 'public', 'basedchat.html')));

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/videos', videosRoutes);
app.use('/api/conversations', conversationsRoutes);

// Multer / generic error handler — keeps upload errors as clean JSON instead of a stack trace.
app.use((err, req, res, next) => {
  if (err) {
    console.error(err);
    return res.status(400).json({ error: err.message || 'Something went wrong.' });
  }
  next();
});

initSockets(io);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`basedchat backend listening on http://localhost:${PORT}`);
});
